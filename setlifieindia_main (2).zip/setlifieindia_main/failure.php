<!DOCTYPE html>
<html>
<head><meta charset="windows-1252">
  <title></title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <?php include 'link.php'; ?>
  <style type="text/css">
        body{  font-family: 'Josefin Sans', sans-serif;  width: 100%; padding: 50px; 

  height: 100%;
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));

    }
     .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        
    </style>
</head>
<body>
    
    <center><a href="https://setlifeindia.in/welcome.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>

</body>
</html>



<?php
$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];

$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$salt="";

// Salt should be same Post Request 

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
  } else {
        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
         }
		 $hash = hash("sha512", $retHashSeq);
  
       if ($hash != $posted_hash) {
	       echo "Invalid Transaction. Please try again";
		   } else {
         echo "<h3>Your order status is ". $status .".</h3>";
         echo "<h4>Your transaction id for this transaction is ".$txnid.". You may try making the payment by clicking the link below.</h4>";
		 } 
?>
