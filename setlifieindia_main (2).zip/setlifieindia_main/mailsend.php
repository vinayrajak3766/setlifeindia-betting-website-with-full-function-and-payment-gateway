<?php

$to_email = "vinayrajak3766@gmail.com";
$subject = "Welcome To Setlifeindia";
$body = "Hii  Thanks for join setlifeindia.in";
$headers = "From : admin@setlifeindia.in";

if(mail($to_email,$subject,$body,$headers)){



	echo"Email successfully sent to $to_email";
}else{
	echo"email sending failed to $to_email";
}


?>