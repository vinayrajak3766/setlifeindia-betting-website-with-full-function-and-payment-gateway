
<div class="card text-center">
  <div class="card-header">
   <b> Withdraw Winnings In Few Hours In Your Provided Account..</b>
  </div>
  <div class="card-body">
    <h5 class="card-title">Our Payment Accept Way</h5>
    <i style="padding-left: 10px;" class="fa fa-university fa-2x" aria-hidden="true"></i>
    <img style="padding-left: 15px;" src="images/upi.png"alt="Upi">
    <img style="padding-left: 15px;" src="images/paytm.gif"alt="paytm">
    <img style="padding-left: 15px;" src="images/master.gif"alt="master">
    <img style="padding-left: 15px;" src="images/visa.gif"alt="visa">
    <img style="padding-left: 15px;" src="images/rupay.jpeg"alt="visa" width="65px" height="40px">
  </div>
</div>
 <div class="card-footer text-muted" style="background-color: white;">
  <center> <i class="fa fa-check-circle" aria-hidden="true"></i>   <b>100% Secure & Legal</b> ||   
   <i class="fa fa-phone" aria-hidden="true"></i>   <b>24/7Customer Support</b> ||
   <i class="fa fa-reply-all" aria-hidden="true"></i>   <b>Reply To All</b>   </center>
  </div><hr>
<div  class="card-footer text-muted" style="background-color: white;">
<h2 align="center">Follow Us</h2><hr>
<div align="center">
<a role="button" href="https://www.instagram.com/setlifeindia.in/?igshid=1psrp4jk4qjr9"> <img src="images/sc(1).png" alt="Instagram"></a>
<a role="button" href="https://twitter.com/setlifeindia"> <img src="images/sc(2).png" alt="Tweeter"></a>
<a role="button" href="https://www.facebook.com/setlifeindia"> <img src="images/sc(3).png" alt="Facebook"></a>
</div>
</div>
<hr>
<div class="card text-center">
  <div class="card-header">
   <b> Total Website Visiters </b>
  </div>
  <div class="card-body">
    <!--<h5 class="card-title">Our Payment Accept Way</h5>-->
    <?php include 'cont.php'; ?>
  </div>
</div>
<div class="footer" style="background-image: linear-gradient(to right, rgba(187, 255, 153), rgba(255, 204, 224)); "> 
<footer class="page-footer font-small blue">
 <div class="footer-copyright text-center py-3">© 2021 Copyright:
    <a href="#">SET-LIFE-INDIA </a><br>
    <small class="text-muted">Made With &#128151; In India</small>
    <hr>
  <p align="center"><i class="fas fa-envelope"></i> admin@setlifeindia.in</p>
  </div>
 </footer>
</div>
