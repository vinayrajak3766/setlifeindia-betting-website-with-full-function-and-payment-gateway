<?php session_start(); 

?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
	<title>Recover Your Account</title>
	<?php include 'link.php'; ?>
    
    <style type="text/css">
        body{  font-family: 'Nunito', sans-serif;  width: 100%; padding: 50px; 
height: 100%; 
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));}
   .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        </style>
</head>
<body>

<?php 

 include 'connection.php';

  if(isset($_POST['submit'])){

  	
  	$email=mysqli_real_escape_string($con, $_POST['email']);
  	
  	

$email_query= "SELECT * FROM users WHERE email='$email' ";

$query= mysqli_query($con,$email_query);

$email_count= mysqli_num_rows($query);

if($email_count){
	$userdata = mysqli_fetch_array($query);

	$fname=$userdata['fname'];
	$token=$userdata['token'];
	
	$subject="Password Reset";
	$body="Hi, $fname Click Hare Too Reset Your Password https://setlifeindia.in/updatepass.php?token=$token";
	$sender_email="From: admin@setlifeindia.in";
	if(mail($email,$subject,$body,$sender_email)){
		$_SESSION['msg']="Check Your Mail To Reset Your Password $email";
		header('location:passresetscr.php');

	}else{
		?>
		<script> alert("Email Sending failed.."); </script>
		<?php
		
	}
	}else{


		?>
		<script> alert("Email Not Found.."); </script>
		<?php
		                             
    }

}
 ?>
	<center>
     <h2>Recover Your Account</h2>
        <p>Please fill this form to forget your password.</p>
    </center>				
					
<form action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" method="POST">
	<div class="form-group">


<ul>
<div class="col-auto">
<input name="email" type="text" class="form-control mb-4" placeholder=" Enter Your Email " required/>
</div></ul>

				

<center><button class="btn btn-success" type="submit" name="submit">Send Mail</button></center></div>
</div>
</form>
<center><p>Already have an account? <a href="login.php">Login here</a>.</p></center>
<center><a href="index.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>
</body>
</html>















