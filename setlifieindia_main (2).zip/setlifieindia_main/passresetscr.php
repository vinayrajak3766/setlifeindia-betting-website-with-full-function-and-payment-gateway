<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
	<title>Email Sent Successfully</title>
	<?php include 'link.php'; ?>
    
    <style type="text/css">
        body{  font-family: 'Nunito', sans-serif;  width: 100%; padding: 50px; 
height: 100%; 
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));}
   .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        </style>
</head>
<body>

<?php 

 

?>  
	<b><p style="text-align: center;">Email Sent Successfully To Your Account..<br></p>
	<p style="text-align: center;"> <?php 
if(isset($_SESSION['msg'])){

	echo $_SESSION['msg'];
}else{
echo $_SESSION['msg']="";
}
	?>.</p></b>

<P style="text-align: center;"> if you not recived email in inbox then check your spam folder also</P>
</body>
</html>















