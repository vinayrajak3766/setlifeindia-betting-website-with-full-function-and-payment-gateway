<?php session_start(); 
if(!isset($_SESSION['email'])){
 
  header('location:index.php');
} 


?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit Profile</title>
	<?php include 'link.php'; ?>
    
    <style type="text/css">
        body{  font-family: 'Nunito', sans-serif;  width: 100%; padding: 50px; 
height: 100%; 
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));}


  .form-control{
 		border: 2;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);

}
.btn {
	border: 0;
	border-radius: 1rem;
	box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);

}
        </style>
</head>
<body>

<?php 

 include 'connection.php';
$ids = $_SESSION['email'];

$sql="SELECT * FROM users WHERE email ='$ids'";

$iq=mysqli_query($con,$sql);

$result=mysqli_fetch_assoc($iq);
	$id=$result['id'];

 
 
  	?>

<div class="container">
	<div class="">
<div align="center" >
	<center>
     <h2>Update Your Profile</h2>
        <p>Please Fill This Form To Update Account</p>
    </center>				
					
<form action="" method="POST">
	<div class="form-group">

<div class="col-auto">	
<u style="color: slategray;">First Name</u>
<input name="fname" type="text" class="form-control mb-4" value="<?php echo $result['fname'];?>" required/>
</div>

<div class="col-auto">
    <u style="color: slategray;">Last Name</u>
<input name="lname" type="text" class="form-control mb-4" value="<?php echo $result['lname'];?>" required/>
</div>



<div class="col-auto">
    <u style="color: slategray;">Phone Number</u>
<input name="pnum" type="text" class="form-control mb-4" value="<?php echo $result['pnum'];?>" required/>
</div>
 
 
<div class="col-auto">
    <u style="color: slategray;">UPI ID</u>
<input name="upi" type="text" class="form-control mb-4" value="<?php echo $result['upi'];?>" />
</div>

<div class="col-auto">
    <u style="color: slategray;">Paytm Number (Paytm KYC is Mandatory for Withdrawing)</u>
<input name="paytm" type="text" class="form-control mb-4" value="<?php echo $result['paytm'];?>" />
</div>
			
<div class="col-auto">
    <u style="color: slategray;">Bank Account Number</u>
<input name="acnum" type="text" class="form-control mb-4" value="<?php echo $result['acnum'];?>" />
</div>

<div class="col-auto">
    <u style="color: slategray;">IFSC</u>
<input name="ifsc" type="text" class="form-control mb-4" value="<?php echo $result['ifsc'];?>" />
</div>	
<div align="center" style="padding-top: 10px;">
<button class="btn btn-success " type="submit" name="submit"><i class="fas fa-sign-in-alt"></i> Update</button>
</div>
</form>

<div style="padding-top: 20px;">
<center><a  href="welcome.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>
</div>
</div>
</div>

<?php
 if(isset($_POST['submit'])){
    $fname=mysqli_real_escape_string($con, $_POST['fname']);
    $lname=mysqli_real_escape_string($con, $_POST['lname']);
    
    $pnum=mysqli_real_escape_string($con, $_POST['pnum']);
  	$upi=mysqli_real_escape_string($con, $_POST['upi']);
  	$paytm=mysqli_real_escape_string($con, $_POST['paytm']);
  	$acnum=mysqli_real_escape_string($con, $_POST['acnum']);
  	$ifsc=mysqli_real_escape_string($con, $_POST['ifsc']);

 $sql = "UPDATE users SET fname='$fname', lname='$lname', pnum='$pnum', upi = '$upi',paytm='$paytm', acnum='$acnum', ifsc= '$ifsc' WHERE id='$id'";
   
 $iquery=mysqli_query($con,$sql);

 if($iquery){
  header('location:profileupdate.php');
 }else{
  echo "Error Update fail";
 }
}

?>


</body>
</html>