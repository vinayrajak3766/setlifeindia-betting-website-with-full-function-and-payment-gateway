<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
	<title>BET HISTORY</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'link.php'; ?>
	<style type="text/css">
        body{  font-family: 'Josefin Sans', sans-serif;  width: 100%; padding: 50px; 

  height: 100%;
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));

    }

    .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
</style>
</head>
<body>
	<nav class="navbar navbar-default navbar-expand-lg navbar-light">
	<div class="navbar-header d-flex col">
		<a class="navbar-brand" href="welcome.php">SET<b>LIFE</b></a>  		
		<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
			<span class="navbar-toggler-icon"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	</div>
	<!-- Collection of nav links, forms, and other content for toggling -->
	<div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
		<ul class="nav navbar-nav">
			<li class="nav-item"><a href="index.php" class="nav-link"><i class="fas fa-home"></i> HOME</a></li>
						
			<li class="nav-item"><a href="icontact.php" class="nav-link"><i class="fas fa-address-book"></i> CONTACT US</a></li>
      <li class="nav-item"><a href="about.php" class="nav-link"> ABOUT</a></li>
      <li class="nav-item"><a href="history.php" class="nav-link">BET HISTORY</a></li>
		</ul>
		
		<ul class="nav navbar-nav navbar-right ml-auto">			
			<li class="nav-item">
				
        
        <b><a href="login.php"  class="btn btn-primary dropdown-toggle get-started-btn mt-1 mb-1"><i class="fa fa-user"></i> Login / Sign Up</a></b>
        
      </li>
		</ul>
	</div>
</nav>
<h1 align="center" style="padding-top: 20px;">Bet Open History!</h1>
<hr>
<?php
$sql="SELECT * from bnumber order by id desc";
$res=mysqli_query($con,$sql);
?>

	
	   <div class="row">
		  <div class="col-xl-10">
			 <div class="table-responsive">
				
				   
				</div>
				
				   
					  <table class="table table-bordered" width="500px">
						 <thead>
							<tr>
							   
							   <th>BET NUMBER</th>
							   <th>DATE</th>
							   
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1;
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   
							   <td><?php echo $row['betnumber']?></td>
							   <td><?php echo $row['date_time']?></td>
							   
							   
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 
		  
	   
	

</body>
</html>
















