





<div class="footer" style="background-image: linear-gradient(to right, rgba(187, 255, 153), rgba(255, 204, 224)); "> 
<footer class="page-footer font-small blue">
 <div class="footer-copyright text-center py-3">Copyright &copy; <?php echo date('Y')?> SET LIFE INDIA<br>
    <small class="text-muted">Made With &#128151; In India</small>
  </div>
 </footer>

</div>

      
   </body>
</html>








