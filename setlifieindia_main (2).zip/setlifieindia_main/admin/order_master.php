<?php
require('top.inc.php');

$sql="select * from users order by id ASC";
$res=mysqli_query($con,$sql);
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">Order Master </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table table-bordered" width="500px">
							<thead>
								<tr>
									<th class="">ID</th>
									<th class="">Name</th>
									<th class="">email</th>
									<th class=""><span class=""> BET NO </span></th>
									<th class=""><span class="">Product </span></th>
									<th class=""><span class=""> amount_paid</span></th>
									<th class=""><span class=""> STATUS </span></th>
									<th class=""><span class=""> Order ID </span></th>
									<th class=""><span class=""> TXNID </span></th>
									<th class=""><span class=""> TXNDATE </span></th>
									
								</tr>
							</thead>
							<tbody>
								<?php
								$res=mysqli_query($con,"SELECT * FROM payu_orders");
								while($row=mysqli_fetch_assoc($res)){
								?>
								<tr>
									<td class="product-add-to-cart"><a href="order_master_detail.php?id=<?php echo $row['id']?>"> <?php echo $row['id']?></a></td>
									<td class="product-name"><?php echo $row['firstname']?></td>
									<td class="product-name"><?php echo $row['email']?></td>
									<td class="product-name"><?php echo $row['bnumber']?></td>
									<td class="product-name"><?php echo $row['products']?></td>
									<td class="product-name"><?php echo $row['amount']?></td>
									<td class="product-name"><?php echo $row['status']?></td>
									<td class="product-name"><?php echo $row['ORDER_ID']?></td>
									<td class="product-name"><?php echo $row['txnid']?></td>
									<td class="product-name"><?php echo $row['txn_date']?></td>

								</tr>
								<?php } ?>
							</tbody>
							
						</table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>