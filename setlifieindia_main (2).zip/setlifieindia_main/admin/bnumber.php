<?php
require('config.php');
 

$bnumber= rand(1,99);
$today = date("Y-m-d");

$sql = "INSERT INTO `bnumber`( `betnumber`, `tempnum`, `date_time`) VALUES ('$bnumber', 'na', '$today')";
    
     $iquery = mysqli_query($con, $sql);

 
?>