<?php
require('connection.inc.php');
//include 'config.php';
require('functions.inc.php');
if(isset($_SESSION['ADMIN_LOGIN']) && $_SESSION['ADMIN_LOGIN']!=''){

}else{
	header('location:login.php');
	die();
}
?>
<!doctype html>
<html class="no-js" lang="">
   
   <head>
      
      <title>Dashboard Page</title>
<link rel="stylesheet" type="text/css" href="style.css">      
      <?php include 'link.php'; ?>

      <style type="text/css">
        body{  font-family: 'Josefin Sans', sans-serif;  width: 100%; padding: 50px; 

  height: 100%;
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));

    }

    .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        
    </style>
   </head>
   <body>

<nav class="navbar navbar-default navbar-expand-lg navbar-light">
   <div class="navbar-header d-flex col">
      <a class="navbar-brand" href="#">SET<b>LIFE<small> Admin</small></b></a>        
      <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
         <span class="navbar-toggler-icon"></span>
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
      </button>
   </div>
   <!-- Collection of nav links, forms, and other content for toggling -->
   <div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
      <ul class="nav navbar-nav">
         <li class="nav-item"><a href="categories.php" class="nav-link">Categories Master</a></li>
                  
         <li class="nav-item"><a href="product.php" class="nav-link">Products</a></li>
      <li class="nav-item"><a href="order_master.php" class="nav-link"> Orders</a></li>

   <li class="nav-item"><a href="users.php" class="nav-link"> Users</a></li>
    <li class="nav-item"><a href="contact_us.php" class="nav-link"> Contact Us</a></li>
    <li class="nav-item"><a href="bnumber.php" class="nav-link"> Bet Num</a></li>
      </ul>
      
      <ul class="nav navbar-nav navbar-right ml-auto">         
         <li class="nav-item">
            
        
        <b><a href="logout.php"  class="btn btn-primary "><i class="fa fa-power-off"></i> Logout</a></b>
        
      </li>
      </ul>
   </div>
</nav>




     
      
         