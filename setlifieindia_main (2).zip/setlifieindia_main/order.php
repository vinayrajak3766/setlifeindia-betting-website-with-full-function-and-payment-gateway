<?php session_start(); 
include 'config.php';
if(!isset($_SESSION['email'])){

  header('location:index.php');
}
?>
<?php
  header("Pragma: no-cache"); 
  header("Cache-Control: no-cache");
  header("Expires: 0");
 


$ids = $_SESSION['email'];

$sql = "SELECT * FROM users WHERE email ='$ids'";

$iq = mysqli_query($con,$sql);

$resultw = mysqli_fetch_assoc($iq);
  $id=$resultw['id'];


?> 

<?php 

if(isset($_GET['id'])){
	$id=$_GET['id'];
	$sql = "SELECT * FROM product WHERE id='$id'";
	$result=mysqli_query($con,$sql);
	$row=mysqli_fetch_array($result);
	$pname=$row['product_name'];
	$pprice=$row['product_price'];

	
	$pimage=$row['product_image'];


}
else{
  ?>
	<script> alert("No product Found!");  </script>
  <?php
}

 ?>
 

<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
	<title>BUY BETTS</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<?php include 'link.php'; ?>
 <style type="text/css">
        body{ font-family: 'Josefin Sans', sans-serif;  width: 100%; padding: 50px; 

  height: 100%;
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));   



 
    </style>
</head>
<body>
<nav class="navbar navbar-default navbar-expand-lg navbar-light">
  <div class="navbar-header d-flex col">
    <a class="navbar-brand" href="welcome.php">SET<b>LIFE</b></a>     
    <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
      <span class="navbar-toggler-icon"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  </div>
  <!-- Collection of nav links, forms, and other content for toggling -->
  <div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
    <ul class="nav navbar-nav ml-auto">
     <li class="nav-item"><a href="welcome.php" class="nav-link"><i class="fas fa-home"></i> HOME</a></li>
            
      
      <li class="nav-item"><a href="wcontact.php" class="nav-link"><i class="fas fa-address-book"></i> CONTACT US</a></li>
      <li class="nav-item"><a href="#" class="nav-link"> ABOUT</a></li>
      
    </ul>
    
    <ul class="nav navbar-nav navbar-right ml-auto">      
      <li class="nav-item">
        <b><a  class="nav-link dropdown-toggle" href="#"></a></b>
        
      </li>
      <li class="nav-item">
        <b><a  class="nav-link dropdown-toggle" href="profileupdate.php?id=<?php echo $resultw['id'];?>"><i class="fas fa-user-edit"></i> Hello! <?php echo $resultw['fname']; ?> </a></b>
        
      </li>
      <li class="nav-item">
        <b><a href="logout.php"  class="btn btn-primary dropdown-toggle get-started-btn mt-1 mb-1">Logout  <i class="fas fa-power-off"></i></a></b>
        
      </li>
    </ul>
  </div>
</nav>





<div class="container" style="padding-top: 20px;">
 
  <div class="row justify-content-center">
  	<div class="col-lg-6 px-4 pb-4" id="order">
  		
  		<div class="jumbotron p-3 mb-2 text-center">
  			<h4 class="text-center text-info p-2">Complete Your Order!</h4>
  		</div>
  		<div class="text-center pt-2"><h3>Product Details!</h3></div> 
  		<table class="table table-bordered" width="500px">
  			<tr>
  				<th>BET NAME :</th>
  				<td><?= $pname;?></td>
  				<td rowspan="4" class="text-center"><img src="<?=$pimage; ?>"width="100"  ></td>
          
  			 </tr>
  			<tr>
  				<th>BET PRICE :</th>
  				<td>Rs.<?=number_format($pprice) ;?> /-</td>
  		  	</tr>
          
  		  	
  			


  		</table>
  		
    


      <form action="Paytm\PaytmKit\pgRedirect.php" method="POST" accept-charset="utf-8" >


        <style type="text/css">
          
 .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}

        </style>
  			
  			<input type="hidden"  name="product_name" value="<?=$pname; ?>">
  			<input type="hidden" name="product_price" value="<?=$pprice; ?>">



        <tr>
          
          
          <td><input type="hidden" id="ORDER_ID" tabindex="1" maxlength="20" size="20"
            name="ORDER_ID" autocomplete="off"
            value="<?php echo  "ORDS" . rand(10000,99999999)?>">
          </td>
        </tr>
        <tr>
          
          <td><input type="hidden" id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="CUST001"></td>
        </tr>
        <tr>
          
          <td><input type="hidden" id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail"></td>
        </tr>
        <tr>
          
          <td><input type="hidden" id="CHANNEL_ID" tabindex="4" maxlength="12"
            size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
          </td>
        </tr>
        <tr>
          
          <td><input type="hidden" title="TXN_AMOUNT" tabindex="10"
            type="text" name="TXN_AMOUNT"
            value="<?= number_format($pprice);?>">
          </td>
        </tr>
        
  			
    <div class="col-auto">
  <input type="tel" name="bnumber" class="form-control mb-4" placeholder="Enter Your Lucky BET No (1-99)" required="required" maxlength="2">
    </div>
<!--<div class="col-auto">-->
<!--      <input type="text" name="phone" class="form-control mb-4" placeholder="Withdrawal No.Paytm/Gpay/PhonePay/UPI" required>-->
<!--      <label>-->
<!--        Ex:- 91*******90 Paytm, Gpay, Phonepay-->
<!--      </label>-->
<!--  </div>-->
      
    <center><input  type="submit" name="submit" class="btn btn-danger btn-lg" value="Click To Pay : Rs <?= number_format($pprice);?>/-"></center>







              
  			</div>
  		</form>
  	</div>
  	
    

  </div>

</div>




</body>
</html>