<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" 
      type="image/png" 
      href="/favicon-16x16.png" />
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SET-LIFE-INDIA</title>
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
  <script src="js/scripts.js"></script>
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar">
    <div class="inner-width">
      <a href="/" class="logo"></a>
      <button class="menu-toggler">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <div class="navbar-menu">
        <a href="#home">Home</a>
        <a href="#services">Features</a>
        <a href="#about">About</a>
        <a href="icontact.php">Contact Us</a>
        <a href="history.php">Bet History</a>
        <!-- <a href="#works">Works</a> -->
        
        
      </div>
    </div>
  </nav>

  <!-- Home -->
  <section id="home">
    <div class="inner-width">
      <div class="content">
        <h1><i class="fa fa-money"></i></h1>
        <div class="sm">
          <a href="https://www.facebook.com/setlifeindia" class="fab fa-facebook-f"></a>
          <a href="https://twitter.com/setlifeindia" class="fab fa-twitter"></a>
          <a href="https://www.instagram.com/setlifeindia.in/?igshid=1psrp4jk4qjr9" class="fab fa-instagram"></a>
          <a href="#" class="fab fa-youtube"></a>
        </div>
        <div class="buttons">
          <a href="login.php">Log-in</a>
          <a href="signup.php">Create Account</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Home -->
  

  <!-- Services -->
  <section id="services" class="dark">
    <div class="inner-width">
      <h1 class="section-title">Our-Features</h1>
      <div class="services">
        <div class="service">
          <i class="icon fas fa-users-cog"></i>  <!-- <i class="fas fa-users-cog"></i> -->
          <h4>Esey To Use</h4>
          <p>Anyone Can Do It Very Easily..</p>
        </div>

        <div class="service">
          <i class="icon fas fa-donate"></i>
          <h4>No Minimum Diposit</h4>
          <p>There Is No Need To Deposit Money..</p> <!-- <i class="fas fa-donate"></i> -->
        </div>

        <div class="service">
          <i class="icon fas fa-money-bill-alt"></i>
          <h4>Start With 1 <i class="fas fa-rupee-sign"></i></h4>
          <p>The Biggest Thing Is Starts At Just 1 Rupee..</p> <!-- <i class="fas fa-money-bill-alt"></i> -->
        </div>
        
        <div class="service">
          <i class="icon fas fa-wallet"></i>
          <h4>No Wallet Top-Up</h4>
          <p>There Is No Wallet Here To Top-Up..</p> <!-- <i class="fas fa-wallet"></i> -->
        </div>

        <div class="service">
          <i class="icon fas fa-university"></i> <!-- <i class="fas fa-university"></i> -->
          <h4>Fast Settelment To Bank/Upi/Wallet</h4>
          <p>Your Winning Money Will Be Deposited In Your Bank Account / UPI Id / Wallet In A Few Hours..</p>
        </div>

        <div class="service">
          <i class="icon fas fa-location-arrow"></i> <!-- <i class="fas fa-location-arrow"></i> -->
          <h4>Direct Pay</h4>
          <p>As We Told You That There Is No Need To Deposit Money In Wallet, You Can Get Direct Purchase..</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Education -->
  <section id="education">
    <div class="inner-width">
      <h1 class="section-title">Users Reviews</h1>
      <div class="time-line">
        <div class="block">
          <h4>Monu Khan</h4>
          <h3>monukhan021096@gmail.com</h3>
          <p>i like so much this website for betting.</p>
        </div>

        <div class="block">
          <h4>Anoop Singh</h4>
          <h3>anoopsingh01062@gmail.com</h3>
          <p>too good site for betting.</p>
        </div>

        <div class="block">
          <h4>Rahul Bhargava</h4>
          <h3>rahulbhargava919@gmail.com</h3>
          <p>payment mode too esay and diposit also.</p>
        </div>

        <div class="block">
          <h4>Yogi Narwariya</h4>
          <h3>yshakya25@gmail.com</h3>
          <p>i never seen so esay site like this site.</p>
        </div>

        <div class="block">
          <h4>Pankaj Shakya</h4>
          <h3>pankajshakya710@gmail.com</h3>
          <p>so esay and simple .</p>
        </div>

        <div class="block">
          <h4>SANJANA PALIYA</h4>
          <h3>sanjanapaliya2@gmail.com</h3>
          <p>very good site for online betting.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Works -->
  <section id="works" class="dark">
    <div class="inner-width">
      <h1 class="section-title">Most Played Bets!</h1>
      <div class="works">
        <a href="images/new_images/image4.jpg" class="work">
          <img src="images/new_images/image4.jpg" alt="">
          <div class="info">
            <h3>Bet Amount 1 <i class="fas fa-rupee-sign"></i></h3>
            <div class="cat">Winning Amount 50 <i class="fas fa-rupee-sign"></i></div>
          </div>
        </a>

        <a href="images/new_images/image5.jpg" class="work">
          <img src="images/new_images/image5.jpg" alt="">
          <div class="info">
            <h3>Bet Amount 2 <i class="fas fa-rupee-sign"></i></h3>
            <div class="cat">Winning Amount 100 <i class="fas fa-rupee-sign"></i></div>
          </div>
        </a>

        <a href="images/new_images/image6.jpg" class="work">
          <img src="images/new_images/image6.jpg" alt="">
          <div class="info">
            <h3>Bet Amount 5 <i class="fas fa-rupee-sign"></i></h3>
            <div class="cat">Winning Amount 250 <i class="fas fa-rupee-sign"></i></div>
          </div>
        </a>

        <a href="images/new_images/image7.jpg" class="work">
          <img src="images/new_images/image7.jpg" alt="">
          <div class="info">
            <h3>Bet Amount 10 <i class="fas fa-rupee-sign"></i></h3>
            <div class="cat">Winning Amount 500 <i class="fas fa-rupee-sign"></i></div>
          </div>
        </a>

        <a href="images/new_images/image8.jpg" class="work">
          <img src="images/new_images/image8.jpg" alt="">
          <div class="info">
            <h3>Bet Amount 20 <i class="fas fa-rupee-sign"></i></h3>
            <div class="cat">Winning Amount 1000 <i class="fas fa-rupee-sign"></i></div>
          </div>
        </a>

        <a href="images/new_images/image9.jpg" class="work">
          <img src="images/new_images/image9.jpg" alt="">
          <div class="info">
            <h3>Bet Amount 30 <i class="fas fa-rupee-sign"></i></h3>
            <div class="cat">Winning Amount 1500 <i class="fas fa-rupee-sign"></i></div>
          </div>
        </a>

         
      </div>
    </div>
  </section>
<section id="about">
    <div class="inner-width">
      <h1 class="section-title">About</h1>
      <div class="about-content">
        <img src="images/new_images/image_px9.jpg" alt="" class="about-pic">
        <div class="about-text">
          <h2>SET-LIFE-INDIA</h2>
          <h3>
            <span>100% Secure & Legal</span>
            <span>24/7 Customer Support</span>
            <span>Reply To All</span>
          </h3>
          <p>
             We have started this with 1 Rs. and we have started this website for those people Who do not understand anything from other websites. And those people think that How will everything be in it. So our website is very simple to play betting. This website is designed to help the poor Peoples. this is trusted website Our payment may be delayed but get paid soon.. And hare is no requerd to topup wallet! types of another website you can direct pay any amount very fast.
          </p>
        </div>
      </div>

      <div class="skills">
        <div class="skill">
          <div class="skill-info">
            <span>BET 1 <i class="fas fa-rupee-sign"></i></span>
            <span>90%</span>
          </div>
          <div class="skill-bar html"></div>
        </div>

        <div class="skill">
          <div class="skill-info">
            <span>BET 2 <i class="fas fa-rupee-sign"></i></span>
            <span>80%</span>
          </div>
          <div class="skill-bar css"></div>
        </div>

        <div class="skill">
          <div class="skill-info">
            <span>BET 5 <i class="fas fa-rupee-sign"></i></span>
            <span>70%</span>
          </div>
          <div class="skill-bar js"></div>
        </div>

        <div class="skill">
          <div class="skill-info">
            <span>BET 10 <i class="fas fa-rupee-sign"></i></span>
            <span>50%</span>
          </div>
          <div class="skill-bar php"></div>
        </div>

        <div class="skill">
          <div class="skill-info">
            <span>BET 20 <i class="fas fa-rupee-sign"></i></span>
            <span>20%</span>
          </div>
          <div class="skill-bar mysql"></div>
        </div>

        <div class="skill">
          <div class="skill-info">
            <span>BET 30 <i class="fas fa-rupee-sign"></i></span>
            <span>10%</span>
          </div>
          <div class="skill-bar cs"></div>
        </div>
      </div>
    </div>
  </section>
  <!-- Contact -->
  <section id="contact">
    <div class="inner-width">
      <h1 class="section-title">Get in touch</h1>
      <div class="contact-info">
        <div class="item">
          <i class="fas fa-mobile-alt"></i>
          +917222970895
        </div>

        <div class="item">
          <i class="fas fa-envelope"></i>
          admin@setlifeindia.in
        </div>

        <div class="item">
          <i class="fas fa-map-marker-alt"></i>
          India
        </div>
      </div>

      <form action="#contact" class="contact-form">
        <input type="text" class="nameZone" name="full_name" placeholder="Your Full Name">
        <input type="email" class="emailZone" name="email" placeholder="Your Email">
        <input type="text" class="subjectZone" name="subject" placeholder="Subject">
        <textarea class="messageZone" name="message" placeholder="Message"></textarea>
        <input type="submit" value="Send Message" class="btn">
      </form>
    </div>
  </section>


  <!-- Footer -->
  <footer>
    <div class="inner-width">
      <div class="copyright">
        &copy; 2021 | Powerd By  <a href="#">SET-LIFE-INDIA</a>
      </div>
      <div class="sm">
          <a href="https://www.facebook.com/setlifeindia" class="fab fa-facebook-f"></a>
          <a href="https://twitter.com/setlifeindia" class="fab fa-twitter"></a>
          <a href="https://www.instagram.com/setlifeindia.in/?igshid=1psrp4jk4qjr9" class="fab fa-instagram"></a>
        
      </div>
      <br>
      <hr>
      <br>
      <div class="sm" style="">
          <img src="images/new_images/paytm.png" height="60" width="60">
          <img src="images/new_images/gpay.png" height="60" width="60">
          <img src="images/new_images/phonepay.png" height="60" width="60">
          <img src="images/new_images/upi.png" height="60" width="60">
          <img src="images/new_images/imps.png" height="60" width="60"> 
      </div>
    </div>
  </footer>

  <!-- Go Top BTN -->
  <button class="goTop fas fa-arrow-up"></button>

</body>
</html>