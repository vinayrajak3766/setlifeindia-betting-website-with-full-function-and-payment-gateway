
<?php include 'connection.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
	<title>SET LIFE</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'link.php'; ?>
	

 <style type="text/css">
        body{  font-family: 'Josefin Sans', sans-serif;  width: 100%; padding: 50px; 

  height: 100%;
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));

    }

    .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        
    </style>

</head>
<body>
<nav class="navbar navbar-default navbar-expand-lg navbar-light">
	<div class="navbar-header d-flex col">
		<a class="navbar-brand" href="index.php">SET<b>LIFE</b></a>  		
		<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
			<span class="navbar-toggler-icon"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	</div>
	<!-- Collection of nav links, forms, and other content for toggling -->
	<div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
    <ul class="nav navbar-nav">
      <li class="nav-item"><a href="index.php" class="nav-link"><i class="fas fa-home"></i> HOME</a></li>
            
      <li class="nav-item"><a href="icontact.php" class="nav-link"><i class="fas fa-address-book"></i> CONTACT US</a></li>
      <li class="nav-item"><a href="about.php" class="nav-link"> ABOUT</a></li>
    </ul>
    
    <ul class="nav navbar-nav navbar-right ml-auto">      
      <li class="nav-item">
        
        
        <b><a href="login.php"  class="btn btn-primary dropdown-toggle get-started-btn mt-1 mb-1"><i class="fa fa-user"></i> Login / Sign Up</a></b>
        
      </li>
    </ul>
  </div>
</nav>


<div class="container" style="padding-top: 30px;">
  <div class="">
    <h2 class="text-center" style="padding-bottom: 30px;">Contact Us</h2>
    <form action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" method="POST">
  <div class="form-group">

<ul><div class="col-auto">            
 <input name="fullname" type="text" class="form-control mb-4" placeholder="Full Name" required/>
</div></ul>

<ul>
<div class="col-auto">
<input name="cemail" type="text" class="form-control mb-4" placeholder="Email" required/>
</div></ul>
<ul>
<div class="col-auto">
<input name="cpnum" type="text" class="form-control mb-4" placeholder="Phone" required/>
</div></ul>
<ul>
<div class="col-auto">
<input name="subject" type="text" class="form-control mb-4" placeholder="Subject" required/>
</div></ul>
<ul>
<div class="col-auto">
<input name="message" type="text" class="form-control mb-4" placeholder=" Your Message" required/>
</div></ul>

        

<center><button class="btn btn-success" type="submit" name="submit"><i class="fas fa-share"></i> Send</button></center>
</div>
</div>
</form>
</div>
<div style="padding-bottom: 30px;">
<center><a  href="index.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>
  </div>
  </div>
</div>



<?php include 'footer.php'; ?>

<?php

if(isset($_POST['submit'])){

    $fullname=mysqli_real_escape_string($con, $_POST['fullname']);
    $cemail=mysqli_real_escape_string($con, $_POST['cemail']);
    $cpnum=mysqli_real_escape_string($con, $_POST['cpnum']);
    $csubject=mysqli_real_escape_string($con, $_POST['subject']);
    $message=mysqli_real_escape_string($con, $_POST['message']);


    $insert_query= "INSERT INTO contact (fullname,cemail,cpnum,subject,message) VALUES('$fullname','$cemail','$cpnum','$csubject','$message')";
    
    $iquery=mysqli_query($con,$insert_query);
    
    if($iquery){

      ?>
      <script> alert('Message Sent Successfully!');</script>
      <?php
      require('wemail.php');
      $subject="Thanks To Contact us";
	  $body="Hi, $fullname Thanks for Contact Us, We Will Respond Soon on.
	  
	  Your Subject:- $csubject .
	 
	  Your Message:- $message .
         
	  
	Thanks & regards,
	https://setlifeinida.in
	";
    
	$sender_email="From: setlifeindia@setlifeindia.in";
	(mail($cemail,$subject,$body,$sender_email));
      
      
    }else{
?>
      <script> alert('Message Not Send');</script>
      <?php

    }
}

?>




</body>
</html>