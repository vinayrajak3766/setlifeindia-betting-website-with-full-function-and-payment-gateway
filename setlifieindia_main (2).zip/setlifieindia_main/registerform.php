<? 
session_start();
 include 'connection.php';
?>
<!DOCTYPE html>
<html>
    
    
    <?php 



  if(isset($_POST['submit'])){

  	$fname = mysqli_real_escape_string($con, $_POST["fname"]);
  	$lname = mysqli_real_escape_string($con, $_POST["lname"]);
  	$email = mysqli_real_escape_string($con, $_POST["email"]);
  	$pnum = mysqli_real_escape_string($con, $_POST["pnum"]);
  	$password = mysqli_real_escape_string($con, $_POST["password"]);
  	$cpassword = mysqli_real_escape_string($con, $_POST["cpassword"]);
  	$pass = password_hash($password,PASSWORD_BCRYPT);
  	$cpass = password_hash($cpassword,PASSWORD_BCRYPT);

$token = bin2hex(random_bytes(16));

$email_query = "SELECT * FROM users WHERE email='$email'";

$query = mysqli_query($con, $email_query);

$email_count = mysqli_num_rows($query);

if($email_count>0){
	?>
<script> alert("email already Register"); </script>

	<?php
	
}else{
	if($password===$cpassword){

        
		
		$sql= "INSERT INTO users (fname, lname, email, pnum, password, cpassword, token) VALUES ('$fname', '$lname', '$email', '$pnum', '$pass', '$cpass', '$token')";
		
	if (mysqli_query($con, $sql)) {
        ?>
        
			<script> alert('Registertion succussfully Please Login'); </script>
			<?php

		}else{
			?>
			<script> alert('Registertion Faild'); </script>
			<?php
		}

	}else{
		
		?>
			<script> alert('Password Not match'); </script>
			<?php

		
	}
}


  
  }
  $con->close();
 ?>
    
    
<head>
	<title>Register Form</title>
	<?php include 'link.php'; ?>
    
    <style type="text/css">
        body{  font-family: 'Nunito', sans-serif;  width: 100%; padding: 50px; 
height: 100%; 
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));}
        </style>
</head>
<body>



 <style type="text/css">
 	
 .form-control{
 		border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
	border: 0;
	border-radius: 1rem;
	box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
 </style>

 <div class="container">
	<div class="">
<div align="center" >
	<center>
     <h2>Sign Up</h2>
        <p>Please Fill This Form To Create An Account</p>
    </center>				
					
<form action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" method="POST">
	<div class="form-group">

<ul><div class="col-auto">						
 <input name="fname" type="text" class="form-control mb-4" placeholder="Enter Fisrt Name" required/>
</div></ul>
<ul>
<div class="col-auto">
<input name="lname" type="text" class="form-control mb-4" placeholder="Enter Last Name" required/>
</div></ul>
<ul>
<div class="col-auto">
<input name="email" type="text" class="form-control mb-4" placeholder="Enter Your Email" required/>
</div></ul>
<ul>
<div class="col-auto">
<input name="pnum" type="text" class="form-control mb-4" placeholder="Enter Phone" required/>
</div></ul>
<ul>
<div class="col-auto">
<input name="password" type="password" class="form-control mb-4" placeholder="Enter password" required/>
</div></ul>
<ul>
<div class="col-auto">
<input name="cpassword" type="password" class="form-control mb-4" placeholder="Enter Conform password" required/>			</div></ul>
				
<div align="center" style="padding-top: 10px;">
<button class="btn btn-success " type="submit" name="submit"><i class="fas fa-sign-in-alt"></i> Sign Up</button>
</div>
</form>

<center><p style="padding-top: 15px;">Already have an account? <a href="login.php">Login here</a>.</p></center>
<center><a href="index.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>
</div>
</div>
</div>




</body>
</html>















