<?php
require('config.php');
 

$bnumber= rand(1,99);
$today = date("Y-m-d");
$sql = "INSERT INTO `bnumber`( `betnumber`, `tempnum`, `date_time`) VALUES ('$bnumber', 'na', '$today')";
    
     $iquery = mysqli_query($con, $sql);

  if ($iquery){
      
         $last_id = $con->insert_id;
  echo "New record created successfully. Last inserted ID is: " . $last_id;
  
       $tempnum = $bnumber;
  
  $updatequery = "UPDATE bnumber SET tempnum = '$tempnum' WHERE id= 1";
  
$iquery = mysqli_query($con,$updatequery);

}

?>