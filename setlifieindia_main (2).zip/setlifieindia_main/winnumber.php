<!DOCTYPE html>
<html>
<head>
	<title>WIN! NUMBER</title>
</head>
<body>
<?php 
$user=20;
$num =rand(1,99);

  echo ($num);  

if($num == $user){
 echo "win!!"; 
}else{
	echo "not win!!";
}

?>


<br>


<?php

$word=("1,1,1,1,1");
$leanth=strlen($word);
echo $leanth;



 ?>





</body>
</html>



