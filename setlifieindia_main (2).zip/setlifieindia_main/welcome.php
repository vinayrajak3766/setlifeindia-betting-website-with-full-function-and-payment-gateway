<?php 
session_start();
if(!isset($_SESSION['email'])){
 
  header('location:index.php');
} 
 include 'connection.php';

$ids = $_SESSION['email'];

$sql = "SELECT * FROM users WHERE email ='$ids'";

$iq = mysqli_query($con,$sql);

$result = mysqli_fetch_assoc($iq);
  $id=$result['id'];

?>


<!DOCTYPE html>
<html>
<head>
	
<link rel="icon" type="image/png"  href="/favicon-16x16.png" />
<title>WELCOME TO SETLIFE</title>
<link rel="stylesheet" type="text/css" href="style.css">
<?php include 'link.php'; ?>
 <style type="text/css">
        body{ 
            /*font-family: 'Josefin Sans', sans-serif;  width: 100%; padding: 50px; */

  /*height: 100%;*/
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));

    }

    .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
     .cc {
        text-align: center;
        font-size: 40px;
        margin-top: 20px;
    }   

.container{text-align: center;}

    h1{
  color: #396;
  font-weight: 100;
  font-size: 40px;
  margin: 40px 0px 20px;
}

#clockdiv{
  font-family: sans-serif;
  color: #fff;
  display: inline-block;
  font-weight: 100;
  text-align: center;
  font-size: 30px;
}

#clockdiv > div{
  padding: 10px;
  border-radius: 3px;
  background: #00BF96;
  display: inline-block;
}

#clockdiv div > span{
  padding: 15px;
  border-radius: 3px;
  background: #00816A;
  display: inline-block;
}

.smalltext{
  padding-top: 5px;
  font-size: 16px;
}
.text-block {
  position: absolute;
  bottom: 20px;
  right: 20px;
  background-color: black;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
    </style>

</head>
<body>
 
  <nav class="navbar navbar-default navbar-expand-lg navbar-light">
  <div class="navbar-header d-flex col">
    <a class="navbar-brand" href="welcome.php">SET<b>LIFE</b></a>     
    <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
      <span class="navbar-toggler-icon"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  </div>
  <!-- Collection of nav links, forms, and other content for toggling -->
  <div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
    <ul class="nav navbar-nav ml-auto">
     <li class="nav-item"><a href="welcome.php" class="nav-link active"><i class="fas fa-home"></i> HOME</a></li>
            
      
      <li class="nav-item"><a href="wcontact.php" class="nav-link"><i class="fas fa-address-book"></i> CONTACT US</a></li>
      <li class="nav-item"><a href="whistory.php" class="nav-link  ">BET HISTORY</a></li>
      
      
  
    </ul>
    
    <ul class="nav navbar-nav navbar-right ml-auto">      
      <li class="nav-item">
        <b><a  class="nav-link dropdown-toggle" href="#"></a></b>
        
      </li>
      <li class="nav-item">
        <b><a  class="nav-link dropdown-toggle" href="profileupdate.php?id=<?php echo $result['id'];?>"><i class="fas fa-user-edit"></i> Hello! <?php echo $result['fname']; ?> </a></b>
        
      </li>
      <li class="nav-item">
        <b><a href="logout.php"  class="btn btn-primary dropdown-toggle get-started-btn mt-1 mb-1">Logout  <i class="fas fa-power-off"></i></a></b>
        
      </li>
    </ul>
  </div>
</nav>

<div align="center" style="  margin-top: 8%; font-family: 'Tenali Ramakrishna', sans-serif; ">
 <img src="images/image29.png" height="350" width="350">
  <h2> India's First Very Simple Betting Site..</h2>
  <h3>Here is Bet Start only 1 RS</h3>
</div>

<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
     <img src="images/image24.jpg" height="450px" width="200px" class="d-block w-100" alt="...">
      <div class="text-block" >
    <h4>No Wallet Top-up Requird</h4>
    <p>No minimum Amount Limit </p>
  </div>
      <div class="carousel-caption d-none d-md-block">
        <h5>Select Any Bet</h5>
        <!--<p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>-->
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/image26.jpeg" height="450px" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Choose Any Number</h5>
        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>-->
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/image12.jpg" height="450px" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Make Payment</h5>
        <!--<p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>-->
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


<div class="container">
   <h1>BET OPEN IN!</h1>
<div id="clockdiv">
  
  <div>
    <span class="hours" id="hours"></span>
    <div class="smalltext">Hours</div>
  </div>
  <div>
    <span class="minutes" id="minutes"></span>
    <div class="smalltext">Minutes</div>
  </div>
  <div>
    <span class="seconds" id="seconds"></span>
    <div class="smalltext">Seconds</div>
  </div>
</div>

 <?php require 'time.php'; ?>




<hr>

<div  class="container">
  <div style="padding-top: 10px; " id="message"></div>
  <div class="row mt-4 pb-4">
    
<?php 
$sql="SELECT * from product";
$res=mysqli_query($con,$sql);
while($row=mysqli_fetch_assoc($res)):

 ?>


 <div class="col mb-4">
<div class="card-group">
    <div class="card " style="width: 15rem;">
    <img src="<?= $row['product_image']?>" class="card-img-top">
    <div class="card-body">
      <h5 class="card-title text-center"><b><?= $row['product_name']?></b></h5>
     <b> <p class="card-text text-center "><i class="fas fa-rupee-sign"></i>&nbsp;<?=number_format($row['product_price'])?>/-</p></b>
     <form action="" class="form-submit">
       <input type="hidden" class="pid" value="<?= $row['id']?>">
       <input type="hidden" class="pname" value="<?= $row['product_name']?>">
       <input type="hidden" class="pprice" value="<?= $row['product_price']?>">
       <input type="hidden" class="pimage" value="<?= $row['product_image']?>">
       <input type="hidden" class="pcode" value="<?= $row['product_code']?>">
       <center><a  class="btn btn-success" href="PayUMoney_form.php?id=<?= $row['id']?>" ><i class="far fa-money-bill-alt"></i> BET NOW</a></center>
     </form>
    
    </div>
    
    <div class="card-footer">
      <small class="text-muted">BE LUCKY BET NOW!</small>
<!--      <div class="progress">-->
<!--  <div class="progress-bar progress-bar-striped progress-bar-animated" style="width:98%">98%</div>-->

<!--</div>-->
    </div>
  </div>
</div>
</div>
<?php endwhile ?>
  </div>
  
</div>
<hr>
<?Php include 'ab.php'; ?>
<hr>
<?php include 'footer.php'; ?>


</body>
</html>