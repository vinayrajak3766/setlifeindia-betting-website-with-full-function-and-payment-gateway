<?php 

session_start();
if(!isset($_SESSION['email'])){
 
  header('location:index.php');
} 
 include 'connection.php';

$ids = $_SESSION['email'];

$sql = "SELECT * FROM users WHERE email ='$ids'";

$iq = mysqli_query($con,$sql);

$result = mysqli_fetch_assoc($iq);
  $id=$result['id'];
?>


<!DOCTYPE html>
<html>
<head>
<link rel="icon" type="image/png"  href="/favicon-16x16.png" />
<title>HISTORY</title>
<link rel="stylesheet" type="text/css" href="style.css">
<?php include 'link.php'; ?>
 <style type="text/css">
        body{ font-family: 'Josefin Sans', sans-serif;  width: 100%; padding: 50px; 

  height: 100%;
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));

    }

    .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
     .cc {
        text-align: center;
        font-size: 40px;
        margin-top: 20px;
    } 
    </style>

</head>
<body> 
 
  <nav class="navbar navbar-default navbar-expand-lg navbar-light">
  <div class="navbar-header d-flex col">
    <a class="navbar-brand" href="welcome.php">SET<b>LIFE</b></a>     
    <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
      <span class="navbar-toggler-icon"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  </div>
  <!-- Collection of nav links, forms, and other content for toggling -->
  <div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
    <ul class="nav navbar-nav ml-auto">
     <li class="nav-item"><a href="welcome.php" class="nav-link "><i class="fas fa-home"></i> HOME</a></li>
            
      
      <li class="nav-item"><a href="wcontact.php" class="nav-link"><i class="fas fa-address-book"></i> CONTACT US</a></li>
      <li class="nav-item"><a href="whistory.php" class="nav-link active "> HISTORY</a></li>
      
       </ul>
  
   
    
    <ul class="nav navbar-nav navbar-right ml-auto">      
      <li class="nav-item">
        <b><a  class="nav-link dropdown-toggle" href="#"></a></b>
        
      </li>
      <li class="nav-item">
        <b><a  class="nav-link dropdown-toggle" href="profileupdate.php?id=<?php echo $result['id'];?>"><i class="fas fa-user-edit"></i> Hello! <?php echo $result['fname']; ?> </a></b>
        
      </li>
      <li class="nav-item">
        <b><a href="logout.php"  class="btn btn-primary dropdown-toggle get-started-btn mt-1 mb-1">Logout  <i class="fas fa-power-off"></i></a></b>
        
      </li>
    </ul>

  </div>
</nav>
<h1 align="center" style="padding-top: 20px;">Bet Open History!</h1>
<hr>
<?php
$sql="SELECT * from bnumber order by id desc";
$res=mysqli_query($con,$sql);
?>

  
     <div class="row">
      <div class="col-xl-10">
       <div class="card">
        
           
        </div>
        
           
            <table class="table table-bordered" width="500px">
             <thead>
              <tr>
                 
                 <th>BET NUMBER</th>
                 <th>DATE</th>
                 
              </tr>
             </thead>
             <tbody>
              <?php 
              $i=1;
              while($row=mysqli_fetch_assoc($res)){?>
              <tr>
                 
                 <td><?php echo $row['betnumber']?></td>
                 <td><?php echo $row['date_time']?></td>
                 
                 
              </tr>
              <?php } ?>
             </tbody>
            </table>
           </div>
        </div>
       
      
     
  

</body>
</html>