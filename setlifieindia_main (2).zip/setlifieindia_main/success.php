<?php
// session_start();
// if(!isset($_SESSION['email'])){
 
//   header('location:index.php');
// } 
 include 'connection.php';

// $ids = $_SESSION['email'];

// $sql = "SELECT * FROM users WHERE email ='$ids'";

// $iq = mysqli_query($con,$sql);

// $result = mysqli_fetch_assoc($iq);
//   $id=$result['id'];


?>




<!DOCTYPE html>
<html>
<head><meta charset="windows-1252">
  <title></title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <?php include 'link.php'; ?>
  <style type="text/css">
        body{  font-family: 'Josefin Sans', sans-serif;  width: 100%; padding: 50px; 

  height: 100%;
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));

    }
     .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        
    </style>
</head>
<body>




<?php
$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$salt="G5mPlycBBX";


// Salt should be same Post Request 

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
  } else {
        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
         }
		 $hash = hash("sha512", $retHashSeq);
       if ($hash != $posted_hash) {
	       echo "Invalid Transaction. Please try again";
		   } else {






$sql = "UPDATE payu_orders SET status='$status' WHERE txnid='$txnid'";

$iquery=mysqli_query($con,$sql);

if($iquery){
  
$sql2 = "SELECT * FROM payu_orders WHERE txnid = '$txnid'";

$iq=mysqli_query($con,$sql2);


while ($result=mysqli_fetch_assoc($iq)) {

// echo $result['ORDER_ID'];

 


?>	




<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8">
      <h1 class="text-center" style="padding-top: 30px;" >ThankYou For BET!</h1>
<p class="text-center"><b>Your Transaction status is success!</b></p>
      
<h2 class="text-center">order Details :</h2>
     <table class="table table-bordered">
      <tr>
        <th>YOU HAVE PURCHASED :</th>
        <td><?php echo $productinfo;?></td>
      </tr>
      <tr>
        <th>Paid Amount :</th>
        <td><?php echo $amount;?></td>
      </tr>
      <tr>
        <th>PAYEE NAME :</th>
        <td><?php echo $firstname;?></td>
      </tr>
      <tr>
        <th>PAYEE Email :</th>
        <td><?php echo $email;?></td>
      </tr>
      <tr>
        <th>PAID STATUS :</th>
        <td><?php echo $status;?></td>
      </tr>
      <tr>
        <th>ORDER ID :</th>
        <td><?php echo $result['ORDER_ID'];?></td>
      </tr>
      <tr>
        <th>TXN ID :</th>
        <td><?php echo $txnid;?></td>
      </tr>
      <tr>
        <th>TXN TIME DATE :</th>
        <td><?php echo $result['txn_date'];?></td>
      </tr>
      <tr>
        <th>YOUR BET NO :</th>
        <td><?php echo $result['bnumber'];?></td>
      </tr>   

<?php $bn= $result['bnumber']; 
$orn= $result['ORDER_ID']; 
$td= $result['txn_date']; 



?>


<?php

$subject="Thanks for BET";
    $body="Hi, $firstname Thanks for Buy BET.
    
    Your Bet Number is:- $bn.
    
    Your Bet Amount is:- $amount .
    
    Your Bet order ID is:- $orn .
    
    Your Bet TXN ID is:- $txnid .
    
          $td
    
    Play Betting And Earn Money Hare Is We Start only With 1RS..
    
    
   
    
    
  Thanks & regards,
  https://setlifeinida.in
  ";
  $sender_email="From: setlifeindia@setlifeindia.in";
  (mail($email,$subject,$body,$sender_email));




     }} }?>
</table>
</div>
</div>
</div>




<center><a href="https://setlifeindia.in/welcome.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>

</body>
</html>
