<!DOCTYPE html>
<html>
<head>
	<title></title>
	

<?php  
include 'connection.php';

$bquery= "SELECT tempnum FROM bnumber WHERE id=1";
$result=mysqli_query($con,$bquery);
  $row=mysqli_fetch_array($result);
  
$tempnum=$row['tempnum'];

// echo"<center><h2> $tempnum</h2> </center>";        


?>

	<p class="cc" id="demo"></p>
   <script>
    
    var countDownDate = <?php echo strtotime('dec 31 2022 24:30:00') ?> * 1000;
   
    var now = <?php echo time() ?> * 1000;

    var x = setInterval(function() {

        now = now + 1000;

        var distance = countDownDate - now;

        
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

      
        // document.getElementById("demo").innerHTML =  hours + "h " +
        //     minutes + "m " + seconds + "s ";

    document.getElementById("hours").innerHTML = hours;
    document.getElementById("minutes").innerHTML = minutes;
    document.getElementById("seconds").innerHTML = seconds;

        
        if (distance < 0) {
            clearInterval(x);
            
             document.getElementById("demo").innerHTML = "<div><strong>Hurray!</strong> Today  <a>Lucky BET No. is!<?php echo"<center><h2> $tempnum</h2> </center>";?> </a></div>";

        }
    }, 1000);
    
    </script>
 </div>



</body>
</html>