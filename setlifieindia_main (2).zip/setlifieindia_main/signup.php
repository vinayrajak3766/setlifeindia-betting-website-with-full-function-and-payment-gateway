<?php 
include "config.php";
?>
<!DOCTYPE html>
<html>
    
    
    
    
    <?php 
$error_message = "";$success_message = "";

// Register user
if(isset($_POST['btnsignup'])){
   $fname = trim($_POST['fname']);
   $lname = trim($_POST['lname']);
   $email = trim($_POST['email']);
   $pnum = trim($_POST['pnum']);
   $password = trim($_POST['password']);
   $confirmpassword = trim($_POST['confirmpassword']);
   $token = bin2hex(random_bytes(16));
   $isValid = true;

   // Check fields are empty or not
   if($fname == '' || $lname == '' || $email == '' || $password == '' || $confirmpassword == ''){
     $isValid = false;
     $error_message = "Please fill all fields.";
   }

   // Check if confirm password matching or not
   if($isValid && ($password != $confirmpassword) ){
     $isValid = false;
     $error_message = "Confirm password not matching";
   }

   // Check if Email-ID is valid or not
   if ($isValid && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
     $isValid = false;
     $error_message = "Invalid Email-ID.";
   }

   if($isValid){

     // Check if Email-ID already exists
     $stmt = $con->prepare("SELECT * FROM users WHERE email = ?");
     $stmt->bind_param("s", $email);
     $stmt->execute();
     $result = $stmt->get_result();
     $stmt->close();
     if($result->num_rows > 0){
       $isValid = false;
       $error_message = "Email-ID is already existed.";
     }

   }

   // Insert records
   if($isValid){
     $insertSQL = "INSERT INTO users(fname,lname,email,pnum,password,token,paytm,upi,acnum,ifsc ) values(?,?,?,?,?,?,'Link','Link','Link','Link')";
     $stmt = $con->prepare($insertSQL);
     $stmt->bind_param("ssssss",$fname,$lname,$email,$pnum,$password,$token);
     $stmt->execute();
     $stmt->close();

     $success_message = "Account created successfully.";
     
     $subject="Welcome To SET LIFE INDIA";
	  $body="Hi, $fname Thanks for Join us.
	  
	  Your Account Created Successfully.
	  
	  Play Betting And Earn Money Hare Is We Start only With 1RS..
	  
	  Your Username :- $email .
	 
	  
	  
	Thanks & regards,
	https://setlifeinida.in
	";
	$sender_email="From: setlifeindia@setlifeindia.in";
	(mail($email,$subject,$body,$sender_email));
     
   }
}
?>
    
    
    
    
    
    
  <head>
      <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
    <title>Create Registration </title>
	<?php include 'link.php'; ?>
    
    <style type="text/css">
        body{  font-family: 'Nunito', sans-serif;  width: 100%; padding: 50px; 
height: 100%; 
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));}
  
  .form-control{
 		border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
	border: 0;
	border-radius: 1rem;
	box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        </style>
  </head>
  <body>
    <div class='container'>
      <div class=''>

        <div class='align="center"' >

          <form method='post' action='<?php echo htmlentities($_SERVER['PHP_SELF']);?>'>

            <center>
     <h2>Sign Up</h2>
        <p>Please Fill This Form To Create An Account</p>
    </center>
            <?php 
            // Display Error message
            if(!empty($error_message)){
            ?>
            <div class="alert alert-danger">
              <strong>Error!</strong> <?= $error_message ?>
            </div>

            <?php
            }
            ?>

            <?php 
            // Display Success message
            if(!empty($success_message)){
            ?>
            <div class="alert alert-success">
              <strong>Success!</strong> <?= $success_message ?>
            </div>

            <?php
            }
            ?>

            <div class="form-group col-auto">
                
              <label for="fname"></label>
              <input type="text" class="form-control mb-3" name="fname" id="fname" required="required" maxlength="80" placeholder="Enter Fisrt Name" >
            </div>
            <div class="form-group col-auto">
              <label for="lname"></label>
              <input type="text" class="form-control mb-3" name="lname" id="lname" required="required" maxlength="80" placeholder="Enter Last Name">
            </div>
            <div class="form-group col-auto">
              <label for="email"></label>
              <input type="email" class="form-control mb-3" name="email" id="email" required="required" maxlength="80" placeholder="Enter Your Email">
            </div>
            <div class="form-group col-auto">
              <label for="Phone"></label>
              <input type="text" class="form-control mb-3" name="pnum" id="pnum" required="required" maxlength="80" placeholder="Enter Your phone number">
            </div>
            <div class="form-group col-auto">
              <label for="password"></label>
              <input type="password" class="form-control mb-3" name="password" id="password" required="required" maxlength="80" placeholder="Enter password">
            </div>
            <div class="form-group col-auto">
              <label for="pwd"></label>
              <input type="password" class="form-control mb-3" name="confirmpassword" id="confirmpassword" onkeyup='' required="required" maxlength="80" placeholder="Enter Conform password">
            </div>
            <div align="center" style="padding-top: 10px;">
            <button class="btn btn-success " type="submit" name="btnsignup"><i class="fas fa-sign-in-alt"></i> Sign Up</button>
            </div>
            <center><p style="padding-top: 15px;">Already have an account? <a href="login.php">Login here</a>.</p></center>
            <center><a href="index.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>
          </form>
        </div>

     </div>
    </div>
    
    
   

    
  </body>
</html>