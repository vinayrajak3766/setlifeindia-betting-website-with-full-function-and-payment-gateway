<div  class="card-footer text-muted" style="background-color: white;">
  
<h2 align="center" class="card-header">Why Use Us! </h2>
<p style="margin-top: 5%; margin-bottom: 5%; margin-left: 10%; margin-right: 10%; font-family: 'Roboto Mono', monospace;  ">Because we have started this with 1 Rs. and we have started this website for those people Who do not understand anything from other websites. And those people think that How will everything be in it. So our website is very simple to play betting. This website is designed to help the poor Peoples. this is trusted website Our payment may be delayed but get paid soon.. 
And hare is no requerd to topup wallet! types of another website you can direct pay any amount very fast.
 
 </p>

</div>