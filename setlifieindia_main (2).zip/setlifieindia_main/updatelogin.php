<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
	<title>Updated Password</title>
	<?php include 'link.php'; ?>
    
    <style type="text/css">
        body{  font-family: 'Nunito', sans-serif;  width: 100%; padding: 50px; 
height: 100%; 
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));}
   .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        </style>
</head>
<body>


	

 
	<b><p style="text-align: center;">Password Update Successfully...</p></b><br><br>
	

<p style="text-align: center;">Please Login Your Account <a href="login.php">Click Hare</a></p>

</body>
</html>















