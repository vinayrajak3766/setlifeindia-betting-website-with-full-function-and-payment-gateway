


<?php
include "config.php";

if(isset($_POST['but_submit'])){

    $email = mysqli_real_escape_string($con,$_POST['email']);
    $password = mysqli_real_escape_string($con,$_POST['password']);

    if ($email != "" && $password != ""){

        $sql_query = "select count(*) as cntUser from users where email='".$email."' and password='".$password."'";
        $result = mysqli_query($con,$sql_query);
        $row = mysqli_fetch_array($result);

        $count = $row['cntUser'];

        if($count > 0){
            $_SESSION['email']=$email;
            //$_SESSION['email']= ['fname'];
            if(isset($_POST['rememberme'])){
				setcookie('emailcookie',$email,time()+86400);
				setcookie('passcookie',$password,time()+86400);

				header('location:welcome.php');
			}else{
				header('location:welcome.php');
			}
            header('Location: welcome.php');
        }else{
            ?>
			<script> alert('Invalid Password or Email'); </script>
			<?php
        }

    }

}

?>

<HTML>
    <HEAD>
        <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
        <title>Sign IN</title>
	<?php include 'link.php'; ?>
    <style type="text/css">
        body{  font-family: 'Nunito', sans-serif;  width: 100%; padding: 50px; 
height: 100%;
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));}
  
  .form-control{
 		border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
	border: 0;
	border-radius: 1rem;
	box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        </style>
    </HEAD>
    <body>
        
        <div class="container">
    <form method="post" action="">
        <div id="div_login">
            	<center>  	
	<h2>Login</h2>
    <p>Please fill in your credentials to login.</p>
    </center>
            <div>
                <input type="text" class="form-control mb-4 " id="txt_uname" name="email" placeholder="Enter Email" required="required" value="<?php if(isset($_COOKIE['emailcookie'])){ echo $_COOKIE['emailcookie'];}?>" />
            </div>
            <div>
                <input type="password" class="form-control mb-4 " id="txt_uname" name="password" placeholder="Enter Password" required="required" value="<?php if(isset($_COOKIE['passcookie'])){ echo $_COOKIE['passcookie'];}?>"/>
            </div>
            <div>
               <div class="form-group">
	<input type="checkbox" name="rememberme"> Remember Me
</div> 
                
                <center><button class="btn btn-success" type="submit" name="but_submit"><i class="fas fa-sign-in-alt"></i> Login Now</button></center></div>
            </div>
        </div>
    </form>
    <center>
<p>Forgot Your Password? <a href="mailrecover.php">Click Hare</a>.</p>
	<p>Don't have an account? <a href="registerform.php">Sign up now</a>.</p></center>
    <center><a href="index.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>
</div>







    </body>
</HTML>

