<?php session_start(); 
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
	<title>Update Password</title>
	<?php include 'link.php'; ?>
    
    <style type="text/css">
        body{  font-family: 'Nunito', sans-serif;  width: 100%; padding: 50px; 
height: 100%; 
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));}


   .form-control{
    border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
.btn {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);
}
        </style>
</head>
<body>

<?php 

 include 'connection.php';

  if(isset($_POST['submit'])){

  	if(isset($_GET['token'])){

  		$token=$_GET['token'];


  	$newpassword=mysqli_real_escape_string($con, $_POST['password']);
  	$cpassword=mysqli_real_escape_string($con, $_POST['cpassword']);
 
  	$pass=($newpassword);
  	$cpass=($cpassword);

  	


	if($newpassword===$cpassword){

		$updatequery="UPDATE users SET password='$pass' WHERE token='$token'";
		
		


		$iquery=mysqli_query($con,$updatequery);
		
		if($iquery){
			
			header('location:updatelogin.php');
		}else{
			$_SESSION['pass']="Your Password is Not Update";
			header('location:updatepass.php');
		}

}else{
	
	?>
<script> alert("Password Not Match"); </script>
	<?php
}
}else{
	?>
<script> alert("Invalid link"); </script>
	<?php
	
}

  
  }
 ?>
	<center>
     <h2>Update New Password</h2>
        <p>Please fill this form to Update your account.</p>
    </center>				
					
<form action="" method="POST">
	<div class="form-group">


<ul>
<div class="col-auto">
<input name="password" type="password" class="form-control mb-4" placeholder="Enter New password" required/>
</div></ul>
<ul>
<div class="col-auto">
<input name="cpassword" type="password" class="form-control mb-4" placeholder="Enter Conform password" required/>			</div></ul>
				

<center><button class="btn btn-success" type="submit" name="submit">Update Password</button></center></div>
</div>
</form>
<center><p>Already have an account? <a href="login.php">Login here</a>.</p></center>
<center><a href="index.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>
</body>
</html>















