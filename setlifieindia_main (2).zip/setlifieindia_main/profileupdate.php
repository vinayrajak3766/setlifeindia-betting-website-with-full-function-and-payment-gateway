<?php session_start(); 
if(!isset($_SESSION['email'])){
 
  header('location:index.php');
} 


?>
<!DOCTYPE html>
<html>
<head>
	<title> Your Profile</title>
	<?php include 'link.php'; ?>
    
    <style type="text/css">
        body{  font-family: 'Nunito', sans-serif;  width: 100%; padding: 50px; 
height: 100%; 
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));}


  .form-control{
 		border: 2;
  border-radius: 1rem;
  box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);

}
.btn {
	border: 0;
	border-radius: 1rem;
	box-shadow: 0 0.8rem 1rem 0 rgba(0, 0, 0, 0.1);

}
        </style>
</head>
<body>



 


<?php 

 include 'connection.php';
$ids = $_SESSION['email'];

$sql="SELECT * FROM users WHERE email ='$ids'";

$iq=mysqli_query($con,$sql);

$result=mysqli_fetch_assoc($iq);
	$id=$result['id'];

 
 $fname=$result['fname'];
$lname=$result['lname'];
$email=$result['email'];
  	?>




<div style="padding-bottom: 25px;">
<center><h2> Your Profile!</h2></center>
</div>





<div align="center">
<div class="card" style="width: 20rem;">
  <img class="card-img-top" src="images/image4.jpg" alt="Card image cap">
  <div class="card-body" >
    <h4 class="card-title"></h4>
    
  </div>
  
  	<div class="#">
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><i class="far fa-user-circle"></i>
   <?php echo $result['fname'];?> <?php echo $result['lname'];?>
 	</li>
    
    <li class="list-group-item"><i class="far fa-envelope"></i>
    	<?php echo $result['email'];?>
    </li>
    <li class="list-group-item"><i class="fas fa-phone"></i>
    	 <?php echo $result['pnum'];?>
    </li>
    
    <li class="list-group-item">
        <h3 style="color: firebrick;"><i style="color: gold;" class="fas fa-trophy"></i><br> Withdrawal Methods!</h3><hr>
     <b style="color: red;"> UPI ID:-</b> <?php echo $result['upi'];?> 
    </li><li class="list-group-item">
     <b style="color: red;"> Paytm:-</b> <?php echo $result['paytm'];?>
    </li><li class="list-group-item">
     <b style="color: red;"> ACCOUNT NO.:-</b> <?php echo $result['acnum'];?>
    </li>
    <li class="list-group-item">
      <b style="color: red;">IFSC:-</b> <?php echo $result['ifsc'];?>
    </li>
    
  </ul>
</div>
  <div class="card-body">

    <div align="center" style="padding-top: 10px;">
<a href="editprofile.php?id=<?php echo $result['id'];?>" class="btn btn-success"  ><i class="fas fa-edit"></i> Edit</a>

</div>


<div style="padding-top: 20px;">
<center><a  href="welcome.php" class="btn btn-dark"><i class="fas fa-home"></i> Back To Home</a></center>
</div>
  </div>
</div>
</div>

 







  
</body>
</html> 















