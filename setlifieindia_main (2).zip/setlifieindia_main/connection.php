
<?php 
$con=new mysqli("localhost","setlifei_setlifeindia","yourpassword","setlifei_setlifeindiadb");
if($con->connect_error){
	die("connection failed!".$con->connect_error);
}

 ?>
 
 
 