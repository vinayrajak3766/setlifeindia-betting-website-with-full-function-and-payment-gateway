<?php
try{
	$con=new PDO("mysql:host=localhost;dbname=setlifei_setlifeindiadb","setlifei_setlifeindia","yourpassword");
}catch(PDOExection $e){
	echo $e->getMessage();
}
?>