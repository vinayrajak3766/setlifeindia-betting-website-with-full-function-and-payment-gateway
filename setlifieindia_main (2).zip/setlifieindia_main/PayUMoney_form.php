<?php
session_start(); 
include 'config.php';
if(!isset($_SESSION['email'])){

  header('location:index.php');
}
$ids = $_SESSION['email'];
// $pnumm = $_SESSION['pnum'];

$sql = "SELECT * FROM users WHERE email ='$ids'";

$iq = mysqli_query($con,$sql);

$resultw = mysqli_fetch_assoc($iq);
  $id=$resultw['id'];

  if(isset($_GET['id'])){
  $id=$_GET['id'];
  $sql = "SELECT * FROM product WHERE id='$id'";
  $result=mysqli_query($con,$sql);
  $row=mysqli_fetch_array($result);
  $pname=$row['product_name'];
  $pprice=$row['product_price'];

  
  $pimage=$row['product_image'];


}
else{
  ?>
  <script> alert("No product Found!");  </script>
  <?php
}


$MERCHANT_KEY = "your MERCHANT_KEY";
$SALT = "your SALT";
// Merchant Key and Salt as provided by Payu.

//$PAYU_BASE_URL = "https://sandboxsecure.payu.in";		// For Sandbox Mode
$PAYU_BASE_URL = "https://secure.payu.in";			// For Production Mode

$action = '';

$posted = array();
if(!empty($_POST)) {
    //print_r($_POST);
  foreach($_POST as $key => $value) {    
    $posted[$key] = $value; 
	
  }
}

$formError = 0;

if(empty($posted['txnid'])) {
  // Generate random transaction id
  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
} else {
  $txnid = $posted['txnid'];
}
$hash = '';
// Hash Sequence
$hashSequence = "key|txnid|amount|productinfo|firstname|email||||||||||";
if(empty($posted['hash']) && sizeof($posted) > 0) {
  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
          || empty($posted['email'])
          || empty($posted['phone'])
          || empty($posted['productinfo'])
          || empty($posted['surl'])
          || empty($posted['furl'])
		      || empty($posted['service_provider'])
  ) {
    $formError = 1;
  } else {
    //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));
	$hashVarsSeq = explode('|', $hashSequence);
    $hash_string = '';	
	foreach($hashVarsSeq as $hash_var) {
      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
      $hash_string .= '|';
    }

    $hash_string .= $SALT;


    $hash = strtolower(hash('sha512', $hash_string));
    $action = $PAYU_BASE_URL . '/_payment';
  }
} elseif(!empty($posted['hash'])) {
  $hash = $posted['hash'];
  $action = $PAYU_BASE_URL . '/_payment';
}
?>
<html>
  <head>

    <link rel="icon" type="image/png"  href="/favicon-16x16.png" />
  <title>BUY BETTS</title>
  <link rel="stylesheet" type="text/css" href="style.css">
<?php include 'link.php'; ?>
 <style type="text/css">
        body{ font-family: 'Josefin Sans', sans-serif;  width: 100%; padding: 50px; 

  height: 100%;
  background-image: linear-gradient(to right, rgba(135,206,235), rgba(255,0,0,0.3));   



 
    </style>

  <script>
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {
      if(hash == '') {
        return;
      }
      var payuForm = document.forms.payuForm;
      payuForm.submit();
    }
  </script>
  </head>
  <body onload="submitPayuForm()">



<nav class="navbar navbar-default navbar-expand-lg navbar-light">
  <div class="navbar-header d-flex col">
    <a class="navbar-brand" href="welcome.php">SET<b>LIFE</b></a>     
    <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle navbar-toggler ml-auto">
      <span class="navbar-toggler-icon"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  </div>
  <!-- Collection of nav links, forms, and other content for toggling -->
  <div id="navbarCollapse" class="collapse navbar-collapse justify-content-start">
    <ul class="nav navbar-nav ml-auto">
     <li class="nav-item"><a href="welcome.php" class="nav-link"><i class="fas fa-home"></i> HOME</a></li>
            
      
      <li class="nav-item"><a href="wcontact.php" class="nav-link"><i class="fas fa-address-book"></i> CONTACT US</a></li>
      <li class="nav-item"><a href="#" class="nav-link"> ABOUT</a></li>
      
    </ul>
    
    <ul class="nav navbar-nav navbar-right ml-auto">      
      <li class="nav-item">
        <b><a  class="nav-link dropdown-toggle" href="#"></a></b>
        
      </li>
      <li class="nav-item">
        <b><a  class="nav-link dropdown-toggle" href="profileupdate.php?id=<?php echo $resultw['id'];?>"><i class="fas fa-user-edit"></i> Hello! <?php echo $resultw['fname']; ?> </a></b>
        
      </li>
      <li class="nav-item">
        <b><a href="logout.php"  class="btn btn-primary dropdown-toggle get-started-btn mt-1 mb-1">Logout  <i class="fas fa-power-off"></i></a></b>
        
      </li>
    </ul>
  </div>
</nav>
<div class="container" style="padding-top: 20px;">
 
  <div class="row justify-content-center">
    <div class="col-lg-6 px-4 pb-4" id="order">
      
      <div class="jumbotron p-3 mb-2 text-center">
        <h4 class="text-center text-info p-2">Complete Your Order!</h4>
      </div>
      <div class="text-center pt-2"><h3>Product Details!</h3></div> 
      <table class="table table-bordered" width="500px">
        <tr>
          <th>BET NAME :</th>
          <td><?= $pname;?></td>
          <td rowspan="4" class="text-center"><img src="<?=$pimage; ?>"width="100"  ></td>
          
         </tr>
        <tr>
          <th>BET PRICE :</th>
          <td>Rs.<?=number_format($pprice) ;?> /-</td>
          </tr>
           </table>




    <!-- <h2>PayU Form</h2>
    <br/> -->
    <?php if($formError) { ?>
	
      <span style="color:red">Please fill all mandatory fields.</span>
      <br/>
      <br/>
    <?php } ?>
    <form action="<?php echo $action; ?>" method="POST" name="payuForm">
      <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
      <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
      <input type="hidden" name="txnid" value="<?php echo $txnid ?>" />
      <table>
        <!-- <tr>
          <td><b>Mandatory Parameters</b></td>
        </tr> -->
        <tr>
          <!-- <td>Amount: </td> -->
          <td><input type="hidden" name="amount" value="<?=number_format($pprice) ;?>" /></td>
         
          <!-- <td>Your Name: </td> -->
          <td><input type="hidden" name="firstname" id="firstname" value="<?php echo $resultw['fname']; ?>" /></td>
        </tr>
        <tr>
         <!--  <td> Your Email: </td> -->
          <td><input type="hidden" name="email" id="email" value="<?php echo $ids = $_SESSION['email']; ?>" /></td>
          <!-- <td>Phone: </td> -->
          <td><input type="hidden" name="phone" value="<?php echo $resultw['pnum']; ?>" /></td>
        </tr>
        <tr>
          <!-- <td>Product Info: </td> -->
          <td colspan="3"><input type="hidden" name="productinfo" value="<?= $pname;?>"> </input></td>
        </tr>
        <tr>
          <!-- <td>Success URI: </td> -->
          <td colspan="3"><input type="hidden" name="surl" value="https://setlifeindia.in/success.php" size="64" /></td>
        </tr>
        <tr>
         <!--  <td>Failure URI: </td> -->
          <td colspan="3"><input type="hidden" name="furl" value="https://setlifeindia.in/failure.php" size="64" /></td>
        </tr>

        <tr>
          <td colspan="3"><input type="hidden" name="service_provider" value="payu_paisa" size="64" /></td>
        </tr>

        <label>ENTER YOUR BET NUMBER</label>
          <input class="form-control mb-4 " type="text" name="bnumber" placeholder="Enter Bet NO.(1-99)" required="required" maxlength="2"></input>

        <input type="hidden" id="ORDER_ID" tabindex="1" maxlength="20" size="20"
            name="ORDER_ID" autocomplete="off"
            value="<?php echo  "ORDS" . rand(10000,99999999)?>">
        
          <?php if(!$hash) { ?>
             <center><input name="submit" class="btn btn-danger btn-lg" type="submit" value="Click To Pay : Rs <?= number_format($pprice);?>/-" /></center>
          <?php } ?>
        </tr>
      </table>
    </form>
  </body>
</html>




<?php 


 
if(isset($_POST['submit'])){

 $ORDER_ID = $_POST["ORDER_ID"];
 $bnumber=$_POST['bnumber'];
 $status="Pending";
 $firstname= $resultw['fname'];
 $amount= $pprice;
 // $txnid="na";
 $email= $resultw['email'];
 $products=$pname;
 $txn_date= date("Y/m/d");



$sql = "INSERT INTO payu_orders(ORDER_ID, status, firstname, amount, txnid, email, products, bnumber, txn_date) VALUES ('$ORDER_ID', '$status', '$firstname', '$amount', '$txnid', '$email', '$products', '$bnumber', '$txn_date')";

$iquery = mysqli_query($con, $sql);

}
 ?>
